/* ===== COBERTURA APP - Vanilla JS Architecture ===== */

// ===== STATE =====
const state = {
  view: 'dashboard',
  navVisible: true,
  filterSegment: null,
  medicoSubTab: 'Panel',
  farmaciaSubTab: 'Panel',
  ciudadMed: 'BOGOTÁ',
  ciudadFarm: 'BOGOTÁ',
  busquedaMed: '',
  busquedaFarm: '',
  especialidadMed: 'Todas',
  estadoMed: 'Todos',
  estadoFarm: 'Todos',
  filtroExtraMed: null,
  notaSubTab: 'Todas',
  dashboardPendFilter: 'Todos',
  pendMedCiudad: 'BOGOTÁ',
  pendFarmCiudad: 'BOGOTÁ',
  modal: null, // {type, data}
  toastTimer: null
};

let usuarioActivo = null; // 'carlos' o 'esposa'

let medicosCache = [];
let farmaciasCache = [];
let visitasMap = {}; // entidadTipo-id -> count
const mesActual = mesActualISO();

// ===== SCROLL NAV =====
let lastScrollY = 0;
let touchStartY = 0;
function setupScroll() {
  const main = document.querySelector('.main-content') || window;
  const onScroll = () => {
    const y = window.scrollY;
    if (y < 10) { setNav(true); lastScrollY = y; return; }
    if (y > lastScrollY + 5) setNav(false);
    else if (y < lastScrollY - 5) setNav(true);
    lastScrollY = y;
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('touchstart', e => { touchStartY = e.touches[0].clientY; }, { passive: true });
  window.addEventListener('touchend', e => {
    const diff = touchStartY - e.changedTouches[0].clientY;
    if (diff > 10) setNav(false); else if (diff < -10) setNav(true);
  }, { passive: true });
}
function setNav(show) {
  state.navVisible = show;
  const nav = document.getElementById('bottom-nav');
  if (nav) nav.classList.toggle('hidden', !show);
}

// ===== TOAST =====
function toast(msg, type) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0'; el.style.transform = 'translateY(-8px)';
    setTimeout(() => el.remove(), 250);
  }, 2500);
}

// ===== RENDER CORE =====
function $(id) { return document.getElementById(id); }
function html(str) { return str; }
function esc(s) {
  const d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}

async function init() {
  // Verificar si hay usuario guardado
  const guardado = localStorage.getItem('cobertura_usuario');
  if (guardado && CONFIG.USUARIOS[guardado]) {
    await seleccionarUsuario(guardado, false);
  } else {
    renderSelectorUsuario();
  }
}

window.seleccionarUsuario = async function(usuario, guardar = true) {
  if (!CONFIG.USUARIOS[usuario]) { toast('Usuario no válido', 'err'); return; }
  usuarioActivo = usuario;
  if (guardar) localStorage.setItem('cobertura_usuario', usuario);

  // Inicializar DB del usuario
  db = new CoberturaDB(usuario);
  await db.init();

  // Cargar bricks personalizados
  const customBricks = await db.getConfig('customBricks');
  if (customBricks?.value) customBricksMap = customBricks.value;

  // Inicializar sheets con el ID del usuario
  await sheets.init();

  await recargarDatos();

  // Si no hay médicos, cargar desde el panel local (solo Carlos tiene datos incrustados)
  if (medicosCache.length === 0 && usuario === 'carlos' && typeof PANEL_DATA !== 'undefined') {
    try {
      await cargarPanelLocal();
      await recargarDatos();
    } catch (e) { console.error('Error cargando panel local:', e); }
  }

  renderApp();
  setupScroll();
  setupEvents();
};

function renderSelectorUsuario() {
  const app = $('app');
  if (!app) return;
  app.innerHTML = `
    <div style="min-height:100dvh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;background:var(--bg)">
      <div style="font-size:2.5rem;margin-bottom:8px">👨‍⚕️</div>
      <h1 style="font-size:1.4rem;margin-bottom:32px;color:var(--text)">Cobertura</h1>
      <p style="font-size:.9rem;color:var(--text2);margin-bottom:24px">Seleccioná tu usuario</p>
      <div style="display:flex;flex-direction:column;gap:12px;width:100%;max-width:280px">
        <button class="btn btn-primary" style="padding:18px;font-size:1rem" onclick="window.seleccionarUsuario('carlos')">
          <div>Carlos</div>
          <div style="font-size:.75rem;font-weight:400;opacity:.8">Adium - Falla Cardíaca</div>
        </button>
        <button class="btn btn-outline" style="padding:18px;font-size:1rem" onclick="window.seleccionarUsuario('esposa')">
          <div>Esposa</div>
          <div style="font-size:.75rem;font-weight:400;opacity:.8">Farmacéutica</div>
        </button>
      </div>
    </div>
  `;
}

async function recargarDatos() {
  medicosCache = await db.getAll('medicos');
  farmaciasCache = await db.getAll('farmacias');
  visitasMap = {};
  for (const m of medicosCache) {
    visitasMap['medico-' + m.id] = await db.countVisitasEntidad(m.id, 'medico', mesActual);
  }
  for (const f of farmaciasCache) {
    visitasMap['farmacia-' + f.id] = await db.countVisitasEntidad(f.id, 'farmacia', mesActual);
  }
}

function renderApp() {
  const app = $('app');
  if (!app) return;
  // Preservar foco activo para evitar perder el cursor en búsqueda
  const activeEl = document.activeElement;
  const activeId = activeEl?.id;
  const selStart = activeEl?.selectionStart;
  const selEnd = activeEl?.selectionEnd;
  app.innerHTML = renderLayout();
  attachHandlers();
  // Restaurar foco y posición del cursor
  if (activeId) {
    const el = $(activeId);
    if (el) {
      el.focus();
      if (selStart !== undefined && el.setSelectionRange) {
        el.setSelectionRange(selStart, selEnd);
      }
    }
  }
}

function renderLayout() {
  const tabs = [
    {k:'dashboard',l:'Dashboard',i:'📊'},
    {k:'medicos',l:'Médicos',i:'👨‍⚕️'},
    {k:'farmacias',l:'Farmacias',i:'🏥'},
    {k:'resumen-panel',l:'Panel',i:'📋'},
    {k:'notas',l:'Notas',i:'📝'},
    {k:'config',l:'Config',i:'⚙️'}
  ];
  return `
    <header class="app-header">
      <h1>Cobertura</h1>
      <div class="header-actions">
        <span style="font-size:.75rem;color:#666">${navigator.onLine?'🟢':'🔴'}</span>
      </div>
    </header>
    <main class="main-content" id="main-content">
      ${renderView()}
    </main>
    <nav class="bottom-nav ${state.navVisible?'':'hidden'}" id="bottom-nav">
      ${tabs.map(t=>`<button class="nav-item ${state.view===t.k?'active':''}" data-view="${t.k}"><span class="nav-icon">${t.i}</span><span class="nav-label">${t.l}</span></button>`).join('')}
    </nav>
    <div class="toast-container" id="toast-container"></div>
    ${renderModal()}
  `;
}

function renderView() {
  switch(state.view) {
    case 'dashboard': return renderDashboard();
    case 'medicos': return renderMedicos();
    case 'farmacias': return renderFarmacias();
    case 'notas': return renderNotas();
    case 'config': return renderConfig();
    case 'resumen-panel': return renderResumenPanel();
    case 'resumen-dias': return renderResumenDias();
    case 'pendientes-medicos': return renderPendientesMedicos();
    case 'pendientes-farmacias': return renderPendientesFarmacias();
    default: return renderDashboard();
  }
}

function attachHandlers() {
  document.querySelectorAll('[data-view]').forEach(el => {
    el.onclick = () => { state.view = el.dataset.view; state.filterSegment = null; state.filtroExtraMed = null; window.scrollTo(0,0); renderApp(); };
  });
  document.querySelectorAll('[data-action]').forEach(el => {
    const action = el.dataset.action;
    const data = el.dataset;
    el.onclick = (e) => handleAction(action, data, e);
  });
}

async function handleAction(action, data, e) {
  if (e) e.stopPropagation();
  switch(action) {
    case 'dash-filter': {
      const lbl = data.label;
      if (lbl === 'Tareas') { state.view = 'notas'; }
      else if (lbl === 'Farmacias Total') { state.view = 'farmacias'; }
      else { state.view = 'medicos'; state.filterSegment = (lbl === 'Médicos Total' ? null : lbl); }
      window.scrollTo(0,0); renderApp(); break;
    }
    case 'set-subtab': {
      if (data.target === 'med') { state.medicoSubTab = data.tab; state.filtroExtraMed = null; }
      else state.farmaciaSubTab = data.tab;
      renderApp(); break;
    }
    case 'set-ciudad': {
      if (data.target === 'med') { state.ciudadMed = data.ciudad; state.filtroExtraMed = null; }
      else state.ciudadFarm = data.ciudad;
      renderApp(); break;
    }
    case 'open-medico': state.modal = {type:'medico', id: parseInt(data.id)}; renderApp(); break;
    case 'open-farmacia': state.modal = {type:'farmacia', id: parseInt(data.id)}; renderApp(); break;
    case 'add-visita-med': state.modal = {type:'calendario', entidadId: parseInt(data.id), entidadTipo:'medico'}; renderApp(); break;
    case 'add-visita-farm': state.modal = {type:'calendario', entidadId: parseInt(data.id), entidadTipo:'farmacia'}; renderApp(); break;
    case 'nota-rapida': state.modal = {type:'nota', medicoId: parseInt(data.id), nombre: data.nombre}; renderApp(); break;
    case 'editar-medico': state.modal = {type:'editar-medico', id: parseInt(data.id)}; renderApp(); break;
    case 'editar-farmacia': state.modal = {type:'editar-farmacia', id: parseInt(data.id)}; renderApp(); break;
    case 'nota-rapida-farm': state.modal = {type:'nota', farmaciaId: parseInt(data.id), nombre: data.nombre}; renderApp(); break;
    case 'close-modal': state.modal = null; renderApp(); break;
    case 'guardar-visita': await guardarVisita(data); break;
    case 'guardar-nota': await guardarNota(); break;
    case 'guardar-alta': await guardarAlta(); break;
    case 'guardar-baja': await guardarBaja(); break;
    case 'toggle-nota': await toggleNota(parseInt(data.id)); break;
    case 'eliminar-visita': {
      await db.delete('visitas', parseInt(data.id));
      await recargarDatos();
      toast('Visita eliminada', 'ok');
      renderApp();
      break;
    }
    case 'sync-sheets': await doSync(); break;
    case 'export-csv': await doExport(); break;
    case 'backup': await doBackup(); break;
    case 'guardar-url': await guardarUrl(); break;
    case 'nueva-nota': state.modal = {type:'nota'}; renderApp(); break;
    case 'nueva-alta': state.modal = {type:'alta'}; renderApp(); break;
    case 'nueva-baja': state.modal = {type:'baja'}; renderApp(); break;
    case 'nuevo-brick': state.modal = {type:'brick'}; renderApp(); break;
    case 'set-nota-tab': state.notaSubTab = data.tab; renderApp(); break;
    case 'cal-select': calSelect(data); break;
    case 'cal-month': calMonth(parseInt(data.delta)); break;
    case 'cal-today': calToday(); break;
    case 'open-dia': state.modal = {type:'dia', fecha: data.fecha}; renderApp(); break;
    case 'editar-visita-fecha': {
      state.modal = {type:'editar-visita', id: parseInt(data.id), fecha: data.fecha};
      renderApp();
      break;
    }
    case 'guardar-visita-editada': guardarVisitaEditada(data); break;
    case 'guardar-medico': await guardarMedico(data); break;
    case 'guardar-farmacia': await guardarFarmacia(data); break;
    case 'guardar-brick': await guardarBrick(); break;
    case 'eliminar-brick': await eliminarBrick(data.brick); break;
    case 'importar-backup': await importarBackup(data); break;
    case 'resumen-filter': {
      const target = data.target;
      if (target === 'medicos') {
        state.view = 'medicos';
        state.filtroExtraMed = null;
        state.ciudadMed = data.ciudad || state.ciudadMed;
        if (data.segmento) { state.medicoSubTab = data.segmento; state.filterSegment = null; }
        if (data.especialidad) { state.especialidadMed = data.especialidad; }
        if (data.filtro === 'H') { state.medicoSubTab = 'H'; state.filterSegment = null; }
        if (data.filtro === 'Deblax') { state.medicoSubTab = 'Deblax'; state.filterSegment = null; }
        if (data.filtro === 'sin-celular') { state.filtroExtraMed = 'sin-celular'; state.medicoSubTab = 'Panel'; }
        if (data.filtro === 'sin-email') { state.filtroExtraMed = 'sin-email'; state.medicoSubTab = 'Panel'; }
        if (data.filtro === 'freq2') { state.filtroExtraMed = 'freq2'; state.medicoSubTab = 'Panel'; }
      } else if (target === 'farmacias') {
        state.view = 'farmacias';
        state.ciudadFarm = data.ciudad || state.ciudadFarm;
        if (data.filtro === 'Adium') { state.farmaciaSubTab = 'Adium tu Aliado'; }
      } else if (target === 'notas') {
        state.view = 'notas';
        if (data.filtro === 'altas') state.notaSubTab = 'Altas';
        if (data.filtro === 'bajas') state.notaSubTab = 'Bajas';
      }
      window.scrollTo(0,0); renderApp(); break;
    }
    case 'set-pend-filter': state.dashboardPendFilter = data.filtro; renderApp(); break;
    case 'open-resumen-dias': state.view = 'resumen-dias'; window.scrollTo(0,0); renderApp(); break;
    case 'open-pendientes-medicos': state.view = 'pendientes-medicos'; window.scrollTo(0,0); renderApp(); break;
    case 'open-pendientes-farmacias': state.view = 'pendientes-farmacias'; window.scrollTo(0,0); renderApp(); break;
    case 'volver-dashboard': state.view = 'dashboard'; window.scrollTo(0,0); renderApp(); break;
    case 'set-pend-ciudad': {
      if (data.target === 'med') state.pendMedCiudad = data.ciudad;
      else state.pendFarmCiudad = data.ciudad;
      renderApp(); break;
    }
    case 'set-especialidad': {
      state.especialidadMed = data.especialidad;
      renderApp(); break;
    }
    case 'set-estado-med': {
      state.estadoMed = data.estado;
      renderApp(); break;
    }
    case 'set-estado-farm': {
      state.estadoFarm = data.estado;
      renderApp(); break;
    }
    case 'cambiar-usuario': {
      localStorage.removeItem('cobertura_usuario');
      location.reload();
      break;
    }
  }
}

function setupEvents() {
  // Delegación para elementos dinámicos
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (btn) handleAction(btn.dataset.action, btn.dataset, e);
  });
}


// ===== DASHBOARD =====
function renderDashboard() {
  const hoy = hoyISO();
  const dht = diasHabilesCicloHasta(hoy);
  const dhMes = diasHabilesMes(new Date().getFullYear(), new Date().getMonth());
  const nombresMes = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const mesActual = nombresMes[new Date().getMonth()];
  const cfg = usuarioActivo && CONFIG.USUARIOS[usuarioActivo] ? CONFIG.USUARIOS[usuarioActivo] : { metaMedicos: 9, metaFarmacias: 2 };
  const metaMed = cfg.metaMedicos;
  const metaFarm = cfg.metaFarmacias;

  // Visitas totales
  const vMed = medicosCache.filter(m => (visitasMap['medico-'+m.id]||0) > 0).length;
  const vFarm = farmaciasCache.filter(f => (visitasMap['farmacia-'+f.id]||0) > 0).length;

  // Cobertura al día
  const pctMed = calcCobertura(vMed, dht, metaMed);
  const pctFarm = calcCobertura(vFarm, dht, metaFarm);
  const clsMed = claseCobGeneral(pctMed);
  const clsFarm = claseCobGeneral(pctFarm);
  const colMed = colorCobGeneral(pctMed);
  const colFarm = colorCobGeneral(pctFarm);

  // % Total mes
  const metaTotalMesMed = dhMes * metaMed;
  const metaTotalMesFarm = dhMes * metaFarm;
  const pctTotalMesMed = metaTotalMesMed > 0 ? Math.round((vMed / metaTotalMesMed) * 100) : 0;
  const pctTotalMesFarm = metaTotalMesFarm > 0 ? Math.round((vFarm / metaTotalMesFarm) * 100) : 0;

  // Meta al día acumulada
  const metaDiaMed = dht * metaMed;
  const metaDiaFarm = dht * metaFarm;

  // Segmentos H, C, P (solo estos tres)
  const segData = ['H','C','P'].map(seg => {
    const lista = medicosCache.filter(m => obtenerSegmentos(m).includes(seg));
    const vr = lista.filter(m => (visitasMap['medico-'+m.id]||0) > 0).length;
    const pct = calcCobertura(vr, dht, metaMed);
    return {seg, vr, total: lista.length, pct, cls: claseCobSegmento(pct), col: colorCobSegmento(pct)};
  });

  // Pendientes conteos
  const pendMedCount = medicosCache.filter(m => {
    const v = visitasMap['medico-'+m.id] || 0;
    return v < (parseInt(m.frecuencia) || 1);
  }).length;
  const pendFarmCount = farmaciasCache.filter(f => {
    const v = visitasMap['farmacia-'+f.id] || 0;
    return v < (parseInt(f.frecuencia) || 1);
  }).length;

  return `
    <div style="background:var(--surface);border-radius:14px;padding:12px 14px;border:1.5px solid var(--border);margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
      <div>
        <div style="font-size:.78rem;color:var(--text2)">Ciclo ${mesActual} ${new Date().getFullYear()}</div>
        <div style="font-size:.95rem;font-weight:700">📅 Día ${dht} de ${dhMes} hábiles</div>
      </div>
      <div style="text-align:right">
        <div style="font-size:.78rem;color:var(--text2)">Hoy</div>
        <div style="font-size:.95rem;font-weight:700">${fmtFecha(hoy)}</div>
      </div>
    </div>

    <!-- TARJETA MÉDICOS -->
    <div class="dash-card ${clsMed}" data-action="dash-filter" data-label="Médicos Total" style="margin-bottom:12px;padding:18px 16px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
        <div style="font-size:1.1rem;font-weight:700">👨‍⚕️ MÉDICOS</div>
        <div style="font-size:1.6rem;font-weight:800;color:${colMed}">${pctMed}%</div>
      </div>
      <div style="font-size:.85rem;color:var(--text2);margin-bottom:8px">Cobertura al día</div>
      <div class="dash-bar" style="margin-bottom:10px"><div class="dash-fill" style="width:${Math.min(pctMed,100)}%;background:${colMed}"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:.78rem;color:var(--text2)">
        <div>Meta al día: <strong>${metaDiaMed}</strong></div>
        <div>Realizadas: <strong>${vMed}</strong></div>
      </div>
      <div style="font-size:.78rem;color:var(--text2);margin-top:4px">% Total mes: <strong>${pctTotalMesMed}%</strong></div>
    </div>

    <!-- TARJETA FARMACIAS -->
    <div class="dash-card ${clsFarm}" data-action="dash-filter" data-label="Farmacias Total" style="margin-bottom:12px;padding:18px 16px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
        <div style="font-size:1.1rem;font-weight:700">🏥 FARMACIAS</div>
        <div style="font-size:1.6rem;font-weight:800;color:${colFarm}">${pctFarm}%</div>
      </div>
      <div style="font-size:.85rem;color:var(--text2);margin-bottom:8px">Cobertura al día</div>
      <div class="dash-bar" style="margin-bottom:10px"><div class="dash-fill" style="width:${Math.min(pctFarm,100)}%;background:${colFarm}"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:.78rem;color:var(--text2)">
        <div>Meta al día: <strong>${metaDiaFarm}</strong></div>
        <div>Realizadas: <strong>${vFarm}</strong></div>
      </div>
      <div style="font-size:.78rem;color:var(--text2);margin-top:4px">% Total mes: <strong>${pctTotalMesFarm}%</strong></div>
    </div>

    <!-- SEGMENTOS H, C, P -->
    <div class="dash-section-title">Segmentos</div>
    <div class="dashboard-grid" style="margin-top:4px;margin-bottom:12px">
      ${segData.map(s => `
        <div class="dash-card ${s.cls}" data-action="dash-filter" data-label="${s.seg}">
          <div class="dash-label">${s.seg}</div>
          <div class="dash-value" style="font-size:1.3rem;font-weight:800;color:${s.col}">${s.pct}%</div>
          <div class="dash-bar"><div class="dash-fill" style="width:${Math.min(s.pct,100)}%;background:${s.col}"></div></div>
          <div style="font-size:.72rem;color:var(--text2);margin-top:6px">${s.vr}/${s.total} · Meta ≥95%</div>
        </div>
      `).join('')}
    </div>

    <!-- ACCIONES RÁPIDAS -->
    <div class="dash-section-title">Acciones rápidas</div>
    <div class="dashboard-grid" style="margin-top:4px">
      <div class="dash-card resumen" data-action="open-resumen-dias">
        <div class="dash-label">📅 Resumen día</div>
        <div class="dash-value">Ver días</div>
      </div>
      <div class="dash-card pend-med" data-action="open-pendientes-medicos">
        <div class="dash-label">👨‍⚕️ Pend. Médicos</div>
        <div class="dash-value">${pendMedCount}</div>
      </div>
      <div class="dash-card pend-farm" data-action="open-pendientes-farmacias">
        <div class="dash-label">🏥 Pend. Farmacias</div>
        <div class="dash-value">${pendFarmCount}</div>
      </div>
    </div>
  `;
}

// ===== RESUMEN PANEL =====
function renderResumenPanel() {
  // --- MÉDICOS ---
  const totalMed = medicosCache.length;
  const medicosBog = medicosCache.filter(m => m.ciudad && m.ciudad.toUpperCase().includes('BOGOTÁ')).length;
  const medicosIba = medicosCache.filter(m => m.ciudad && m.ciudad.toUpperCase().includes('IBAGUÉ')).length;

  const segCounts = {};
  for (const seg of ['H','C','P','M','E','PS']) {
    segCounts[seg] = medicosCache.filter(m => obtenerSegmentos(m).includes(seg)).length;
  }

  const espCounts = {};
  for (const m of medicosCache) {
    if (m.especialidad) espCounts[m.especialidad] = (espCounts[m.especialidad] || 0) + 1;
  }
  const espSorted = Object.entries(espCounts).sort((a,b) => b[1] - a[1]);

  const medH = medicosCache.filter(m => obtenerSegmentos(m).includes('H')).length;
  const medDeblax = medicosCache.filter(m => m.deblax === true).length;
  const medSinCel = medicosCache.filter(m => !m.celular || m.celular.trim() === '').length;
  const medSinEmail = medicosCache.filter(m => !m.email || m.email.trim() === '').length;
  const medFreq2 = medicosCache.filter(m => (parseInt(m.frecuencia) || 1) >= 2).length;

  // --- FARMACIAS ---
  const totalFarm = farmaciasCache.length;
  const farmBog = farmaciasCache.filter(f => f.ciudad && f.ciudad.toUpperCase().includes('BOGOTÁ')).length;
  const farmIba = farmaciasCache.filter(f => f.ciudad && f.ciudad.toUpperCase().includes('IBAGUÉ')).length;
  const farmAdium = farmaciasCache.filter(f => f.adium === true).length;

  // --- BRICKS ---
  const bricksMed = [...new Set(medicosCache.map(m => m.brick).filter(Boolean))];
  const bricksFarm = [...new Set(farmaciasCache.map(f => f.brick).filter(Boolean))];
  const allBricks = [...new Set([...bricksMed, ...bricksFarm])];
  const bricksBog = allBricks.filter(b => {
    const z = getBrickZona(b);
    return z && !z.toUpperCase().includes('IBAGUÉ');
  }).length;
  const bricksIba = allBricks.filter(b => {
    const z = getBrickZona(b);
    return z && z.toUpperCase().includes('IBAGUÉ');
  }).length;

  // --- PENDIENTES VEEVA (Altas/Bajas) ---
  // Se cargan async
  setTimeout(async () => {
    const notas = await db.getAll('notas');
    const altas = notas.filter(n => n.tipo === 'alta' && !n.completada).length;
    const bajas = notas.filter(n => n.tipo === 'baja' && !n.completada).length;
    const elA = $('rp-altas');
    const elB = $('rp-bajas');
    if (elA) elA.textContent = altas;
    if (elB) elB.textContent = bajas;
  }, 0);

  return `
    <div style="font-size:1.1rem;font-weight:700;margin-bottom:14px">📋 Resumen Panel</div>

    <!-- MÉDICOS -->
    <div style="background:var(--surface);border-radius:14px;padding:14px;border:1.5px solid var(--border);margin-bottom:12px">
      <div style="font-size:.9rem;font-weight:700;margin-bottom:10px">👨‍⚕️ Médicos en Panel</div>
      <div style="font-size:1.4rem;font-weight:800;margin-bottom:12px">${totalMed}</div>

      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Por ciudad</div>
      <div class="dashboard-grid" style="margin-bottom:12px">
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-ciudad="BOGOTÁ">
          <div class="dash-label">Bogotá</div>
          <div class="dash-value">${medicosBog} <span style="font-size:.75rem">(${totalMed>0?Math.round(medicosBog/totalMed*100):0}%)</span></div>
          <div class="dash-bar"><div class="dash-fill" style="width:${totalMed>0?medicosBog/totalMed*100:0}%;background:#4a5568"></div></div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-ciudad="IBAGUÉ">
          <div class="dash-label">Ibagué</div>
          <div class="dash-value">${medicosIba} <span style="font-size:.75rem">(${totalMed>0?Math.round(medicosIba/totalMed*100):0}%)</span></div>
          <div class="dash-bar"><div class="dash-fill" style="width:${totalMed>0?medicosIba/totalMed*100:0}%;background:#4a5568"></div></div>
        </div>
      </div>

      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Por segmento</div>
      <div class="dashboard-grid" style="margin-bottom:12px">
        ${['H','C','P','M','E','PS'].map(seg => {
          const cnt = segCounts[seg] || 0;
          return `
            <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-segmento="${seg}">
              <div class="dash-label">${seg}</div>
              <div class="dash-value">${cnt} <span style="font-size:.75rem">(${totalMed>0?Math.round(cnt/totalMed*100):0}%)</span></div>
              <div class="dash-bar"><div class="dash-fill" style="width:${totalMed>0?cnt/totalMed*100:0}%;background:#4a5568"></div></div>
            </div>
          `;
        }).join('')}
      </div>

      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Especialidades</div>
      <div style="max-height:200px;overflow-y:auto;margin-bottom:12px">
        ${espSorted.map(([esp, cnt]) => `
          <div class="list-item" data-action="resumen-filter" data-target="medicos" data-especialidad="${esc(esp)}">
            <div class="list-info">
              <div class="list-name" style="font-size:.85rem">${esc(esp)}</div>
              <div class="list-meta">${cnt} médico${cnt!==1?'s':''} · ${totalMed>0?Math.round(cnt/totalMed*100):0}%</div>
            </div>
            <div class="list-actions"><span style="font-size:.9rem;font-weight:700">${cnt}</span></div>
          </div>
        `).join('')}
      </div>

      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Otros filtros</div>
      <div class="dashboard-grid">
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-filtro="H">
          <div class="dash-label">Médicos H</div>
          <div class="dash-value">${medH}</div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-filtro="Deblax">
          <div class="dash-label">Con Deblax</div>
          <div class="dash-value">${medDeblax}</div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-filtro="sin-celular">
          <div class="dash-label">Sin celular ⚠️</div>
          <div class="dash-value">${medSinCel}</div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-filtro="sin-email">
          <div class="dash-label">Sin email ⚠️</div>
          <div class="dash-value">${medSinEmail}</div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="medicos" data-filtro="freq2">
          <div class="dash-label">Frecuencia 2+</div>
          <div class="dash-value">${medFreq2}</div>
        </div>
      </div>
    </div>

    <!-- FARMACIAS -->
    <div style="background:var(--surface);border-radius:14px;padding:14px;border:1.5px solid var(--border);margin-bottom:12px">
      <div style="font-size:.9rem;font-weight:700;margin-bottom:10px">🏥 Farmacias</div>
      <div style="font-size:1.4rem;font-weight:800;margin-bottom:12px">${totalFarm}</div>

      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Por ciudad</div>
      <div class="dashboard-grid" style="margin-bottom:12px">
        <div class="dash-card" data-action="resumen-filter" data-target="farmacias" data-ciudad="BOGOTÁ">
          <div class="dash-label">Bogotá</div>
          <div class="dash-value">${farmBog} <span style="font-size:.75rem">(${totalFarm>0?Math.round(farmBog/totalFarm*100):0}%)</span></div>
          <div class="dash-bar"><div class="dash-fill" style="width:${totalFarm>0?farmBog/totalFarm*100:0}%;background:#4a5568"></div></div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="farmacias" data-ciudad="IBAGUÉ">
          <div class="dash-label">Ibagué</div>
          <div class="dash-value">${farmIba} <span style="font-size:.75rem">(${totalFarm>0?Math.round(farmIba/totalFarm*100):0}%)</span></div>
          <div class="dash-bar"><div class="dash-fill" style="width:${totalFarm>0?farmIba/totalFarm*100:0}%;background:#4a5568"></div></div>
        </div>
      </div>

      <div class="dashboard-grid">
        <div class="dash-card" data-action="resumen-filter" data-target="farmacias" data-filtro="Adium">
          <div class="dash-label">Adium tu Aliado</div>
          <div class="dash-value">${farmAdium}</div>
        </div>
      </div>
    </div>

    <!-- BRICKS -->
    <div style="background:var(--surface);border-radius:14px;padding:14px;border:1.5px solid var(--border);margin-bottom:12px">
      <div style="font-size:.9rem;font-weight:700;margin-bottom:10px">🏗️ Bricks</div>
      <div style="font-size:1.4rem;font-weight:800;margin-bottom:8px">${allBricks.length}</div>
      <div style="font-size:.85rem;color:var(--text2)">Bogotá: <strong>${bricksBog}</strong> · Ibagué: <strong>${bricksIba}</strong></div>
    </div>

    <!-- PENDIENTES VEEVA -->
    <div style="background:var(--surface);border-radius:14px;padding:14px;border:1.5px solid var(--border);margin-bottom:12px">
      <div style="font-size:.9rem;font-weight:700;margin-bottom:10px">📋 Pendientes Veeva</div>
      <div class="dashboard-grid">
        <div class="dash-card" data-action="resumen-filter" data-target="notas" data-filtro="altas">
          <div class="dash-label">Altas</div>
          <div class="dash-value" id="rp-altas">—</div>
        </div>
        <div class="dash-card" data-action="resumen-filter" data-target="notas" data-filtro="bajas">
          <div class="dash-label">Bajas</div>
          <div class="dash-value" id="rp-bajas">—</div>
        </div>
      </div>
    </div>
  `;
}

// ===== MEDICOS =====
function renderMedicos() {
  const subTabs = usuarioActivo === 'carlos'
    ? ['Panel','H','C','P','M','E','PS','Brick','Deblax']
    : ['Panel','H','C','P','M','E','PS','Brick'];
  const tabsHtml = subTabs.map(t => `<button class="sub-tab ${state.medicoSubTab===t?'active':''}" data-action="set-subtab" data-tab="${t}" data-target="med">${t}</button>`).join('');

  let filtrados = medicosCache.filter(m => {
    if (m.ciudad && !m.ciudad.toUpperCase().includes(state.ciudadMed)) return false;
    if (state.medicoSubTab === 'Panel') return true;
    if (state.medicoSubTab === 'Brick') return true;
    if (state.medicoSubTab === 'Deblax') return m.deblax === true;
    return obtenerSegmentos(m).includes(state.medicoSubTab);
  });

  // Filtros extra desde Resumen Panel
  if (state.filtroExtraMed === 'sin-celular') {
    filtrados = filtrados.filter(m => !m.celular || m.celular.trim() === '');
  } else if (state.filtroExtraMed === 'sin-email') {
    filtrados = filtrados.filter(m => !m.email || m.email.trim() === '');
  } else if (state.filtroExtraMed === 'freq2') {
    filtrados = filtrados.filter(m => (parseInt(m.frecuencia) || 1) >= 2);
  }

  if (state.filterSegment && state.filterSegment !== 'Médicos Total') {
    filtrados = filtrados.filter(m => obtenerSegmentos(m).includes(state.filterSegment));
  }

  if (state.busquedaMed.trim()) {
    const b = state.busquedaMed.toLowerCase();
    filtrados = filtrados.filter(m => m.nombre.toLowerCase().includes(b));
  }

  // Filtro especialidad
  if (state.especialidadMed && state.especialidadMed !== 'Todas') {
    filtrados = filtrados.filter(m => m.especialidad === state.especialidadMed);
  }

  // Filtro estado
  if (state.estadoMed === 'Visitados') {
    filtrados = filtrados.filter(m => {
      const v = visitasMap['medico-'+m.id] || 0;
      return v >= (parseInt(m.frecuencia) || 1);
    });
  } else if (state.estadoMed === 'Pendientes') {
    filtrados = filtrados.filter(m => {
      const v = visitasMap['medico-'+m.id] || 0;
      return v < (parseInt(m.frecuencia) || 1);
    });
  }

  // Ordenamiento: H primero, luego alfabético
  filtrados.sort((a, b) => {
    const aH = obtenerSegmentos(a).includes('H');
    const bH = obtenerSegmentos(b).includes('H');
    if (aH && !bH) return -1;
    if (!aH && bH) return 1;
    return a.nombre.localeCompare(b.nombre);
  });

  // Especialidades únicas para dropdown
  const especialidades = ['Todas', ...[...new Set(medicosCache.map(m => m.especialidad).filter(Boolean))].sort()];
  const espHtml = `<select class="filter-select" onchange="window.cambiarEsp(this.value)">
    ${especialidades.map(e => `<option value="${esc(e)}" ${state.especialidadMed===e?'selected':''}>${esc(e)}</option>`).join('')}
  </select>`;

  const estados = ['Todos','Visitados','Pendientes'];
  const estadoHtml = estados.map(e =>
    `<button class="estado-btn ${state.estadoMed===e?'active':''}" data-action="set-estado-med" data-estado="${e}">${e}</button>`
  ).join('');

  if (state.medicoSubTab === 'Brick') {
    const porBrick = {};
    for (const m of filtrados) { const b = m.brick || 'Sin brick'; if(!porBrick[b]) porBrick[b]=[]; porBrick[b].push(m); }
    const bricks = Object.keys(porBrick).sort();
    return `
      <div class="city-filters">
        <button class="city-btn ${state.ciudadMed==='BOGOTÁ'?'active':''}" data-action="set-ciudad" data-ciudad="BOGOTÁ" data-target="med">BOGOTÁ</button>
        <button class="city-btn ${state.ciudadMed==='IBAGUÉ'?'active':''}" data-action="set-ciudad" data-ciudad="IBAGUÉ" data-target="med">IBAGUÉ</button>
      </div>
      <div class="sub-tabs">${tabsHtml}</div>
      <div class="extra-filters">
        ${espHtml}
        <div class="estado-filters">${estadoHtml}</div>
      </div>
      ${bricks.map(b => {
        const zona = porBrick[b][0]?.brickZona || '';
        const brickTitle = zona ? `BRICK ${esc(b)} - ${esc(zona)}` : `BRICK ${esc(b)}`;
        return `
        <div class="brick-group">
          <div class="brick-title">${brickTitle}</div>
          <div class="lista">${porBrick[b].map(m => renderMedicoItem(m)).join('')}</div>
        </div>
        `;
      }).join('')}
      ${filtrados.length===0?'<div class="empty-state">No hay médicos</div>':''}
    `;
  }

  return `
    <div class="city-filters">
      <button class="city-btn ${state.ciudadMed==='BOGOTÁ'?'active':''}" data-action="set-ciudad" data-ciudad="BOGOTÁ" data-target="med">BOGOTÁ</button>
      <button class="city-btn ${state.ciudadMed==='IBAGUÉ'?'active':''}" data-action="set-ciudad" data-ciudad="IBAGUÉ" data-target="med">IBAGUÉ</button>
    </div>
    <div class="sub-tabs">${tabsHtml}</div>
    <div class="extra-filters">
      ${espHtml}
      <div class="estado-filters">${estadoHtml}</div>
    </div>
    <input class="search-box" id="busqueda-med" placeholder="Buscar médico..." value="${esc(state.busquedaMed)}" oninput="window.buscarMed(this.value)">
    <div class="lista">
      ${filtrados.map(m => renderMedicoItem(m)).join('')}
    </div>
    ${filtrados.length===0?'<div class="empty-state">No hay médicos</div>':''}
  `;
}

function renderMedicoItem(m) {
  const v = visitasMap['medico-'+m.id] || 0;
  const frec = parseInt(m.frecuencia) || 1;
  const st = estadoVisita(v, frec);
  const segs = obtenerSegmentos(m);
  const brickMeta = m.brick ? (m.brickZona ? `Brick ${esc(m.brick)} · ${esc(m.brickZona)}` : `Brick ${esc(m.brick)}`) : '';
  const completo = v >= frec;
  return `
    <div class="list-item">
      <div class="semaforo ${st.cls}" title="${st.lbl}"></div>
      <div class="list-info" data-action="open-medico" data-id="${m.id}">
        <div class="list-name">${esc(m.nombre)}</div>
        <div class="list-meta">${esc(m.especialidad)}${brickMeta ? ' · ' + brickMeta : ''}</div>
      </div>
      <div class="list-segs">${segs.map(s=>`<span class="seg-badge seg-${s.toString().trim().toLowerCase()}">${s}</span>`).join('')}</div>
      <div class="list-actions">
        <button class="btn-icon" data-action="editar-medico" data-id="${m.id}" title="Editar">✏️</button>
        <button class="btn-icon" data-action="nota-rapida" data-id="${m.id}" data-nombre="${esc(m.nombre)}" title="Nota">📝</button>
        ${completo ? '<span class="btn-icon" style="background:#c6f6d5;color:#276749;font-size:1rem">✓</span>' : `<button class="btn-icon" data-action="add-visita-med" data-id="${m.id}" title="Visita">+</button>`}
      </div>
    </div>
  `;
}

window.buscarMed = function(v) { state.busquedaMed = v; renderApp(); };
window.cambiarEsp = function(v) { state.especialidadMed = v; renderApp(); };

// ===== FARMACIAS =====
function renderFarmacias() {
  const subTabs = usuarioActivo === 'carlos'
    ? ['Panel','Brick','Adium tu Aliado']
    : ['Panel','Brick'];
  const tabsHtml = subTabs.map(t => `<button class="sub-tab ${state.farmaciaSubTab===t?'active':''}" data-action="set-subtab" data-tab="${t}" data-target="farm">${t}</button>`).join('');

  let filtrados = farmaciasCache.filter(f => {
    if (f.ciudad && !f.ciudad.toUpperCase().includes(state.ciudadFarm)) return false;
    if (state.farmaciaSubTab === 'Adium tu Aliado') return f.adium === true;
    return true;
  });

  // Filtro estado farmacias
  if (state.estadoFarm === 'Visitadas') {
    filtrados = filtrados.filter(f => {
      const v = visitasMap['farmacia-'+f.id] || 0;
      return v >= (parseInt(f.frecuencia) || 1);
    });
  } else if (state.estadoFarm === 'Pendientes') {
    filtrados = filtrados.filter(f => {
      const v = visitasMap['farmacia-'+f.id] || 0;
      return v < (parseInt(f.frecuencia) || 1);
    });
  }

  filtrados.sort((a,b) => a.nombre.localeCompare(b.nombre));

  const estadosFarm = ['Todos','Visitadas','Pendientes'];
  const estadoFarmHtml = estadosFarm.map(e =>
    `<button class="estado-btn ${state.estadoFarm===e?'active':''}" data-action="set-estado-farm" data-estado="${e}">${e}</button>`
  ).join('');

  if (state.farmaciaSubTab === 'Brick') {
    const porBrick = {};
    for (const f of filtrados) { const b = f.brick || 'Sin brick'; if(!porBrick[b]) porBrick[b]=[]; porBrick[b].push(f); }
    const bricks = Object.keys(porBrick).sort();
    return `
      <div class="city-filters">
        <button class="city-btn ${state.ciudadFarm==='BOGOTÁ'?'active':''}" data-action="set-ciudad" data-ciudad="BOGOTÁ" data-target="farm">BOGOTÁ</button>
        <button class="city-btn ${state.ciudadFarm==='IBAGUÉ'?'active':''}" data-action="set-ciudad" data-ciudad="IBAGUÉ" data-target="farm">IBAGUÉ</button>
      </div>
      <div class="sub-tabs">${tabsHtml}</div>
      <div class="extra-filters">
        <div class="estado-filters">${estadoFarmHtml}</div>
      </div>
      ${bricks.map(b => {
        const zona = porBrick[b][0]?.brickZona || '';
        const brickTitle = zona ? `BRICK ${esc(b)} - ${esc(zona)}` : `BRICK ${esc(b)}`;
        return `
        <div class="brick-group">
          <div class="brick-title">${brickTitle}</div>
          <div class="lista">${porBrick[b].map(f => renderFarmaciaItem(f)).join('')}</div>
        </div>
        `;
      }).join('')}
      ${filtrados.length===0?'<div class="empty-state">No hay farmacias</div>':''}
    `;
  }

  return `
    <div class="city-filters">
      <button class="city-btn ${state.ciudadFarm==='BOGOTÁ'?'active':''}" data-action="set-ciudad" data-ciudad="BOGOTÁ" data-target="farm">BOGOTÁ</button>
      <button class="city-btn ${state.ciudadFarm==='IBAGUÉ'?'active':''}" data-action="set-ciudad" data-ciudad="IBAGUÉ" data-target="farm">IBAGUÉ</button>
    </div>
    <div class="sub-tabs">${tabsHtml}</div>
    <div class="extra-filters">
      <div class="estado-filters">${estadoFarmHtml}</div>
    </div>
    <div class="lista">
      ${filtrados.map(f => renderFarmaciaItem(f)).join('')}
    </div>
    ${filtrados.length===0?'<div class="empty-state">No hay farmacias</div>':''}
  `;
}

function renderFarmaciaItem(f) {
  const v = visitasMap['farmacia-'+f.id] || 0;
  const frec = parseInt(f.frecuencia) || 1;
  const st = estadoVisita(v, frec);
  const brickMeta = f.brick ? (f.brickZona ? `Brick ${esc(f.brick)} · ${esc(f.brickZona)}` : `Brick ${esc(f.brick)}`) : '';
  const completo = v >= frec;
  return `
    <div class="list-item">
      <div class="semaforo ${st.cls}" title="${st.lbl}"></div>
      <div class="list-info" data-action="open-farmacia" data-id="${f.id}">
        <div class="list-name">${esc(f.nombre)}</div>
        <div class="list-meta">${esc(f.cadena)}${brickMeta ? ' · ' + brickMeta : ''}</div>
      </div>
      <div class="list-actions">
        <button class="btn-icon" data-action="editar-farmacia" data-id="${f.id}" title="Editar">✏️</button>
        <button class="btn-icon" data-action="nota-rapida-farm" data-id="${f.id}" data-nombre="${esc(f.nombre)}" title="Nota">📝</button>
        ${completo ? '<span class="btn-icon" style="background:#c6f6d5;color:#276749;font-size:1rem">✓</span>' : `<button class="btn-icon" data-action="add-visita-farm" data-id="${f.id}" title="Visita">+</button>`}
      </div>
    </div>
  `;
}


// ===== NOTAS =====
function renderNotas() {
  const tabs = ['Todas','Generales','Altas','Bajas'];
  const tabsHtml = tabs.map(t =>
    `<button class="sub-tab ${state.notaSubTab===t?'active':''}" data-action="set-nota-tab" data-tab="${t}">${t}</button>`
  ).join('');

  db.getAll('notas').then(notas => {
    notas.sort((a,b) => new Date(b.creado) - new Date(a.creado));
    let filtradas = notas;
    if (state.notaSubTab === 'Generales') filtradas = notas.filter(n => !n.tipo || n.tipo === 'general');
    else if (state.notaSubTab === 'Altas') filtradas = notas.filter(n => n.tipo === 'alta');
    else if (state.notaSubTab === 'Bajas') filtradas = notas.filter(n => n.tipo === 'baja');

    const el = $('notas-lista');
    if (!el) return;
    el.innerHTML = filtradas.map(n => renderNotaItem(n)).join('') +
      (filtradas.length===0?'<div class="empty-state">Sin notas</div>':'');
  });

  return `
    <div class="action-row">
      <button class="btn btn-outline" data-action="nueva-nota">📝 Nota</button>
      <button class="btn btn-outline" data-action="nueva-alta" style="color:#166534;border-color:#bbf7d0">➕ Alta</button>
      <button class="btn btn-outline" data-action="nueva-baja" style="color:#991b1b;border-color:#fecaca">➖ Baja</button>
    </div>
    <div class="sub-tabs">${tabsHtml}</div>
    <div class="lista" id="notas-lista"><div class="empty-state">Cargando...</div></div>
  `;
}

function renderNotaItem(n) {
  const tipoLabel = n.tipo === 'alta' ? '<span class="nota-tipo nota-tipo-alta">Alta</span>' :
    n.tipo === 'baja' ? '<span class="nota-tipo nota-tipo-baja">Baja</span>' :
    '<span class="nota-tipo nota-tipo-general">Nota</span>';
  let contenido = n.texto || '';
  if (n.tipo === 'alta' && n.nombreAlta) contenido = `Alta: ${esc(n.nombreAlta)} — ${esc(n.especialidadAlta||'')}`;
  if (n.tipo === 'baja' && n.nombreBaja) contenido = `Baja: ${esc(n.nombreBaja)} — ${esc(n.motivoBaja||'')}`;
  return `
    <div class="list-item" data-action="toggle-nota" data-id="${n.id}">
      <div class="list-info">
        <div class="list-name" style="text-decoration:${n.completada?'line-through':'none'};opacity:${n.completada?0.6:1}">${tipoLabel}${contenido}</div>
        ${n.fecha ? `<div class="list-meta">📅 ${fmtFecha(n.fecha)}</div>` : ''}
      </div>
    </div>
  `;
}

async function toggleNota(id) {
  const n = await db.getById('notas', id);
  if (!n) return;
  n.completada = !n.completada;
  await db.put('notas', n);
  renderApp();
}

// ===== CONFIG =====
function renderConfig() {
  db.getConfig('sheetsUrl').then(c => {
    const el = $('cfg-url');
    if (el && c?.value) el.value = c.value;
  });
  db.getConfig('lastSync').then(c => {
    const el = $('cfg-last');
    if (el && c?.value) el.textContent = 'Último sync: ' + new Date(c.value).toLocaleString('es-CO');
  });

  const usuarioLabel = usuarioActivo ? (CONFIG.USUARIOS[usuarioActivo]?.nombre || usuarioActivo) : '—';
  const metaMed = usuarioActivo ? CONFIG.USUARIOS[usuarioActivo].metaMedicos : 9;
  const metaFarm = usuarioActivo ? CONFIG.USUARIOS[usuarioActivo].metaFarmacias : 2;

  setTimeout(() => renderBricksConfigList(), 0);

  return `
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">👤 Usuario activo</h3>
      <div style="font-size:1.1rem;font-weight:700;margin-bottom:4px">${esc(usuarioLabel)}</div>
      <div class="text-sm text-secondary mb-1">Meta médicos: ${metaMed}/día · Meta farmacias: ${metaFarm}/día</div>
      <button class="btn btn-outline" data-action="cambiar-usuario">Cambiar usuario</button>
    </div>
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">🔗 Google Sheets</h3>
      <div class="form-group">
        <label class="form-label">URL del panel</label>
        <input class="form-input" id="cfg-url" placeholder="https://docs.google.com/spreadsheets/d/...">
      </div>
      <button class="btn btn-outline mb-1" data-action="guardar-url">Guardar URL</button>
      <button class="btn btn-primary" data-action="sync-sheets">🔄 Sincronizar ahora</button>
      <div class="text-xs text-secondary mt-1" id="cfg-last"></div>
    </div>
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">📤 Exportar</h3>
      <button class="btn btn-outline" data-action="export-csv">Exportar visitas del mes a Excel (CSV)</button>
    </div>
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">📥 Cargar Excel</h3>
      <p class="text-sm text-secondary mb-1">Sube tu archivo .xlsx directamente (hojas "Médicos" y "Farmacias")</p>
      <input type="file" id="cfg-file" accept=".xlsx,.xls" style="margin-bottom:8px" onchange="window.handleExcelFile(this)">
    </div>
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">🏗️ Gestionar Bricks</h3>
      <div id="bricks-config-list" style="margin-bottom:10px"></div>
      <button class="btn btn-primary" data-action="nuevo-brick">+ Agregar brick</button>
      <div class="text-xs text-secondary mt-1">Bricks personalizados se guardan localmente</div>
    </div>
    <div style="background:var(--surface);border-radius:12px;padding:16px;border:1px solid var(--border);margin-bottom:12px">
      <h3 style="font-size:.9rem;margin-bottom:12px">💾 Backup JSON</h3>
      <button class="btn btn-outline mb-1" data-action="backup">📤 Exportar backup</button>
      <input type="file" id="cfg-backup-file" accept=".json" style="margin-bottom:8px" onchange="window.importarBackup(this)">
      <div class="text-xs text-secondary">Seleccioná un .json para restaurar</div>
    </div>
  `;
}

async function guardarUrl() {
  const v = ($('cfg-url')?.value || '').trim();
  if (!v) { toast('Ingresa una URL', 'err'); return; }
  await sheets.setUrl(v);
  toast('URL guardada', 'ok');
}

async function doSync() {
  try {
    const r = await sheets.syncAll();
    await recargarDatos();
    toast(`Sync OK: ${r.medicos} médicos, ${r.farmacias} farmacias`, 'ok');
    renderApp();
  } catch (e) {
    toast('Error: ' + e.message, 'err');
  }
}

async function doExport() {
  try {
    await sheets.exportarVisitasMes(mesActualISO());
    toast('CSV descargado', 'ok');
  } catch (e) {
    toast('Error: ' + e.message, 'err');
  }
}

async function doBackup() {
  const medicos = await db.getAll('medicos');
  const farmacias = await db.getAll('farmacias');
  const visitas = await db.getAll('visitas');
  const notas = await db.getAll('notas');
  const customBricks = await db.getConfig('customBricks');
  const data = {medicos, farmacias, visitas, notas, customBricks: customBricks?.value || {}, fecha: new Date().toISOString()};
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
  const u = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = u; a.download = `backup_cobertura_${hoyISO()}.json`; a.click();
  URL.revokeObjectURL(u);
  await db.setConfig('lastBackup', new Date().toISOString());
  toast('Backup descargado', 'ok');
}

async function renderBricksConfigList() {
  const el = $('bricks-config-list');
  if (!el) return;
  const custom = await db.getConfig('customBricks');
  const bricks = custom?.value || {};
  const allBricks = {...BRICK_ZONA, ...bricks};
  const entries = Object.entries(allBricks).sort((a,b) => a[0].localeCompare(b[0]));
  if (entries.length === 0) { el.innerHTML = '<div class="text-sm text-secondary">Sin bricks</div>'; return; }
  el.innerHTML = entries.map(([num, zona]) => {
    const esCustom = bricks.hasOwnProperty(num);
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border)">
        <div style="font-size:.82rem"><strong>BRICK ${esc(num)}</strong> — ${esc(zona)}${esCustom?' <span style="color:#319795;font-size:.7rem">(custom)</span>':''}</div>
        ${esCustom ? `<button class="btn-icon" style="width:28px;height:28px;font-size:.8rem" data-action="eliminar-brick" data-brick="${esc(num)}" title="Eliminar">🗑️</button>` : ''}
      </div>
    `;
  }).join('');
  attachHandlers();
}

function renderBrickModal() {
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>🏗️ Agregar Brick</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Número de brick</label><input id="edit-brick-num" placeholder="Ej: 8809"></div>
          <div class="form-group"><label>Nombre de la zona</label><input id="edit-brick-zona" placeholder="Ej: CHICO COLSANITAS"></div>
          <button class="btn btn-primary" data-action="guardar-brick">Guardar</button>
        </div>
      </div>
    </div>
  `;
}

async function guardarBrick() {
  const num = ($('edit-brick-num')?.value || '').trim();
  const zona = ($('edit-brick-zona')?.value || '').trim();
  if (!num || !zona) { toast('Ingresá número y zona', 'err'); return; }
  const custom = await db.getConfig('customBricks');
  const bricks = custom?.value || {};
  bricks[num] = zona;
  await db.setConfig('customBricks', bricks);
  customBricksMap = {...customBricksMap, ...bricks};
  toast('Brick guardado', 'ok');
  state.modal = null;
  renderBricksConfigList();
  await recargarDatos();
  renderApp();
}

async function eliminarBrick(num) {
  if (!confirm('¿Eliminar brick ' + num + '?')) return;
  const custom = await db.getConfig('customBricks');
  const bricks = custom?.value || {};
  delete bricks[num];
  await db.setConfig('customBricks', bricks);
  customBricksMap = {...BRICK_ZONA, ...bricks};
  toast('Brick eliminado', 'ok');
  renderBricksConfigList();
  await recargarDatos();
  renderApp();
}

window.importarBackup = async function(input) {
  const file = input.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!data.medicos || !data.farmacias) { toast('Archivo inválido', 'err'); return; }
    if (confirm(`Restaurar backup de ${data.fecha || 'fecha desconocida'}?\n${data.medicos.length} médicos, ${data.farmacias.length} farmacias`)) {
      await db.reemplazarMedicos(data.medicos);
      await db.reemplazarFarmacias(data.farmacias);
      if (data.visitas) {
        const vs = await db.getAll('visitas');
        for (const v of vs) await db.delete('visitas', v.id);
        for (const v of data.visitas) await db.add('visitas', v);
      }
      if (data.notas) {
        const ns = await db.getAll('notas');
        for (const n of ns) await db.delete('notas', n.id);
        for (const n of data.notas) await db.add('notas', n);
      }
      if (data.customBricks) {
        await db.setConfig('customBricks', data.customBricks);
        customBricksMap = {...BRICK_ZONA, ...data.customBricks};
      }
      await recargarDatos();
      renderApp();
      toast('Backup restaurado', 'ok');
    }
  } catch (e) {
    toast('Error: ' + e.message, 'err');
    console.error(e);
  }
  input.value = '';
};

// ===== MODALES =====
function renderModal() {
  if (!state.modal) return '';
  switch(state.modal.type) {
    case 'medico': return renderMedicoModal(state.modal.id);
    case 'farmacia': return renderFarmaciaModal(state.modal.id);
    case 'calendario': return renderCalendarioModal();
    case 'nota': return renderNotaModal();
    case 'alta': return renderAltaModal();
    case 'baja': return renderBajaModal();
    case 'brick': return renderBrickModal();
    case 'dia': return renderDiaModal(state.modal.fecha);
    case 'editar-visita': return renderEditarVisitaModal(state.modal.id, state.modal.fecha);
    case 'editar-medico': return renderEditarMedicoModal(state.modal.id);
    case 'editar-farmacia': return renderEditarFarmaciaModal(state.modal.id);
    default: return '';
  }
}

function renderMedicoModal(id) {
  const m = medicosCache.find(x => x.id === id);
  if (!m) return '';
  const segs = obtenerSegmentos(m);
  setTimeout(() => loadModalVisitas(id, 'medico'), 0);
  setTimeout(() => loadModalNotasEntidad(id, 'medico'), 0);
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>${esc(m.nombre)}</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="modal-info-grid">
            <div><span class="text-sm text-secondary">Especialidad</span><div>${esc(m.especialidad)||'—'}</div></div>
            <div><span class="text-sm text-secondary">Segmento</span><div>${segs.join(', ')||'—'}</div></div>
            <div><span class="text-sm text-secondary">Frecuencia</span><div>${m.frecuencia||1} visita(s)/mes</div></div>
            <div><span class="text-sm text-secondary">Ciudad</span><div>${esc(m.ciudad)||'—'}</div></div>
            <div><span class="text-sm text-secondary">Brick</span><div>${esc(m.brick)||'—'}${m.brickZona?' · '+esc(m.brickZona):''}</div></div>
            <div><span class="text-sm text-secondary">Celular</span><div>${esc(m.celular)||'—'}</div></div>
          </div>
          <div class="form-group" style="margin-bottom:6px"><span class="text-sm text-secondary">Dirección</span><div>${esc(m.direccion)||'—'}</div></div>
          <div class="form-group" style="margin-bottom:6px"><span class="text-sm text-secondary">Email</span><div>${esc(m.email)||'—'}</div></div>
          <div id="modal-notas-entidad"></div>
          <div id="modal-visitas"></div>
        </div>
      </div>
    </div>
  `;
}

function loadModalVisitas(id, tipo) {
  db.visitasPorEntidad(id, tipo).then(vs => {
    const el = $('modal-visitas');
    if (!el) return;
    const mesVs = vs.filter(v => v.mes === mesActual);
    if (mesVs.length === 0) { el.innerHTML = ''; return; }
    el.innerHTML = `
      <div class="form-group" style="margin-top:12px">
        <span class="text-sm text-secondary">Visitas este mes</span>
        <div class="visitas-list">
          ${mesVs.map(v => `
            <div class="visita-item">
              <span class="visita-fecha">${fmtFecha(v.fecha)}</span>
              <div style="display:flex;gap:4px">
                <button class="btn-icon btn-edit" data-action="editar-visita-fecha" data-id="${v.id}" data-fecha="${v.fecha}" title="Cambiar fecha">✏️</button>
                <button class="btn-icon btn-danger" data-action="eliminar-visita" data-id="${v.id}" title="Eliminar visita">🗑️</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    attachHandlers();
  });
}

async function loadModalNotasEntidad(id, tipo) {
  const el = $('modal-notas-entidad');
  if (!el) return;
  const notas = await db.getAll('notas');
  const previas = notas.filter(n => {
    if (tipo === 'medico' && n.medicoId === id) return true;
    if (tipo === 'farmacia' && n.farmaciaId === id) return true;
    return false;
  }).sort((a,b) => new Date(b.creado) - new Date(a.creado));
  if (previas.length === 0) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="form-group" style="margin-top:12px">
      <span class="text-sm text-secondary">Notas</span>
      <div class="visitas-list">
        ${previas.map(n => `
          <div class="visita-item" style="align-items:flex-start">
            <div>
              ${n.tipo === 'alta' ? '<span class="nota-tipo nota-tipo-alta">Alta</span>' : n.tipo === 'baja' ? '<span class="nota-tipo nota-tipo-baja">Baja</span>' : '<span class="nota-tipo nota-tipo-general">Nota</span>'}
              <span style="opacity:${n.completada?0.6:1};text-decoration:${n.completada?'line-through':'none'};font-size:.82rem">${esc(n.texto)}</span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderFarmaciaModal(id) {
  const f = farmaciasCache.find(x => x.id === id);
  if (!f) return '';
  setTimeout(() => loadModalVisitas(id, 'farmacia'), 0);
  setTimeout(() => loadModalNotasEntidad(id, 'farmacia'), 0);
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>${esc(f.nombre)}</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="modal-info-grid">
            <div><span class="text-sm text-secondary">Cadena</span><div>${esc(f.cadena)||'—'}</div></div>
            <div><span class="text-sm text-secondary">Ciudad</span><div>${esc(f.ciudad)||'—'}</div></div>
            <div><span class="text-sm text-secondary">Brick</span><div>${esc(f.brick)||'—'}${f.brickZona?' · '+esc(f.brickZona):''}</div></div>
            <div><span class="text-sm text-secondary">Frecuencia</span><div>${f.frecuencia||1} visita(s)/mes</div></div>
          </div>
          <div class="form-group" style="margin-bottom:6px"><span class="text-sm text-secondary">Dirección</span><div>${esc(f.direccion)||'—'}</div></div>
          <div id="modal-notas-entidad"></div>
          <div id="modal-visitas"></div>
        </div>
      </div>
    </div>
  `;
}

// Calendario modal state
let calState = {y: new Date().getFullYear(), m: new Date().getMonth()};
function renderCalendarioModal() {
  const first = new Date(calState.y, calState.m, 1).getDay();
  const dim = new Date(calState.y, calState.m + 1, 0).getDate();
  const prev = new Date(calState.y, calState.m, 0).getDate();
  const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const hoy = hoyISO();
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>Seleccionar fecha</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="flex gap-2" style="justify-content:center;margin-bottom:12px">
            <button class="btn-icon" data-action="cal-month" data-delta="-1">◀</button>
            <strong>${months[calState.m]} ${calState.y}</strong>
            <button class="btn-icon" data-action="cal-month" data-delta="1">▶</button>
          </div>
          <div class="cal-grid">
            ${['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'].map(d=>`<div class="cal-day-h">${d}</div>`).join('')}
            ${Array.from({length:first}).map((_,i)=>`<div class="cal-day other">${prev-first+1+i}</div>`).join('')}
            ${Array.from({length:dim}).map((_,i)=>{
              const d=i+1;
              const ds=`${calState.y}-${String(calState.m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
              const cls=['cal-day']; if(ds===hoy) cls.push('today');
              return `<div class="${cls.join(' ')}" data-action="cal-select" data-fecha="${ds}">${d}</div>`;
            }).join('')}
          </div>
          <button class="btn btn-primary mt-1" data-action="cal-today">Hoy</button>
        </div>
      </div>
    </div>
  `;
}

function calMonth(delta) {
  const d = new Date(calState.y, calState.m + delta, 1);
  calState = {y: d.getFullYear(), m: d.getMonth()};
  renderApp();
}

function calSelect(data) {
  guardarVisita({fecha: data.fecha, entidadId: state.modal.entidadId, entidadTipo: state.modal.entidadTipo});
}

function calToday() {
  guardarVisita({fecha: hoyISO(), entidadId: state.modal.entidadId, entidadTipo: state.modal.entidadTipo});
}

async function guardarVisita(data) {
  await db.add('visitas', {
    entidadId: parseInt(data.entidadId),
    entidadTipo: data.entidadTipo,
    fecha: data.fecha,
    mes: data.fecha.slice(0,7),
    notas: '',
    creado: new Date().toISOString()
  });
  await recargarDatos();
  toast('Visita registrada', 'ok');
  state.modal = null;
  renderApp();
}

function renderNotaModal() {
  const prefill = state.modal || {};
  setTimeout(() => loadModalNotasPrevias(prefill.medicoId, prefill.farmaciaId), 0);
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>${prefill.nombre ? 'Nota rápida: ' + esc(prefill.nombre) : 'Nueva nota'}</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div id="notas-previas"></div>
          <textarea class="form-textarea" id="nota-texto" placeholder="Escribe la nota..."></textarea>
          <label class="checkbox-row">
            <input type="checkbox" id="nota-cal">
            Agregar al calendario
          </label>
          <div class="form-group mt-1 hidden" id="nota-fecha-wrap">
            <input type="date" class="form-input" id="nota-fecha" value="${hoyISO()}">
          </div>
          <button class="btn btn-primary mt-1" data-action="guardar-nota">Guardar nota</button>
        </div>
      </div>
    </div>
  `;
}

async function loadModalNotasPrevias(medicoId, farmaciaId) {
  const el = $('notas-previas');
  if (!el || (!medicoId && !farmaciaId)) return;
  const notas = await db.getAll('notas');
  const previas = notas.filter(n => {
    if (medicoId && n.medicoId === medicoId) return true;
    if (farmaciaId && n.farmaciaId === farmaciaId) return true;
    return false;
  }).sort((a,b) => new Date(b.creado) - new Date(a.creado)).slice(0, 5);
  if (previas.length === 0) return;
  el.innerHTML = `
    <div style="margin-bottom:12px">
      <div style="font-size:.78rem;font-weight:600;color:var(--text2);margin-bottom:6px">Notas previas</div>
      ${previas.map(n => `
        <div style="background:var(--bg);border-radius:8px;padding:8px 10px;margin-bottom:6px;font-size:.82rem">
          ${n.tipo === 'alta' ? '<span class="nota-tipo nota-tipo-alta">Alta</span>' : n.tipo === 'baja' ? '<span class="nota-tipo nota-tipo-baja">Baja</span>' : '<span class="nota-tipo nota-tipo-general">Nota</span>'}
          <span style="opacity:${n.completada?0.6:1};text-decoration:${n.completada?'line-through':'none'}">${esc(n.texto)}</span>
        </div>
      `).join('')}
    </div>
  `;
}

async function guardarNota() {
  const texto = ($('nota-texto')?.value || '').trim();
  if (!texto) { toast('Escribe algo', 'err'); return; }
  const agregarCal = $('nota-cal')?.checked || false;
  const fecha = $('nota-fecha')?.value || null;
  const prefill = state.modal || {};
  await db.add('notas', {
    texto,
    tipo: 'general',
    medicoId: prefill.medicoId || null,
    farmaciaId: prefill.farmaciaId || null,
    fecha: agregarCal ? fecha : null,
    completada: false,
    creado: new Date().toISOString()
  });
  toast('Nota guardada', 'ok');
  state.modal = null;
  renderApp();
}

function renderAltaModal() {
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>➕ Nueva Alta</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Nombre completo</label><input id="alta-nombre" placeholder="Nombre del médico/farmacia"></div>
          <div class="form-group"><label>Cédula</label><input id="alta-cc" placeholder="Número de cédula"></div>
          <div class="form-group"><label>Celular</label><input id="alta-celular" placeholder="Teléfono"></div>
          <div class="form-group"><label>Email</label><input id="alta-email" placeholder="correo@ejemplo.com"></div>
          <div class="form-group"><label>Especialidad</label><input id="alta-especialidad" placeholder="Ej: Cardiología"></div>
          <div class="form-group"><label>Ciudad</label><input id="alta-ciudad" placeholder="Ej: BOGOTÁ"></div>
          <div class="form-group"><label>Dirección</label><input id="alta-direccion" placeholder="Dirección completa"></div>
          <div class="form-group"><label>Observaciones</label><textarea id="alta-obs" placeholder="Notas adicionales..."></textarea></div>
          <button class="btn btn-primary" data-action="guardar-alta">Guardar Alta</button>
        </div>
      </div>
    </div>
  `;
}

function renderBajaModal() {
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>➖ Nueva Baja</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Nombre</label><input id="baja-nombre" placeholder="Nombre del médico/farmacia"></div>
          <div class="form-group"><label>Motivo</label><textarea id="baja-motivo" placeholder="Motivo de la baja..."></textarea></div>
          <button class="btn btn-primary" data-action="guardar-baja">Guardar Baja</button>
        </div>
      </div>
    </div>
  `;
}

async function guardarAlta() {
  const nombre = ($('alta-nombre')?.value || '').trim();
  if (!nombre) { toast('Ingresá el nombre', 'err'); return; }
  await db.add('notas', {
    tipo: 'alta',
    nombreAlta: nombre,
    ccAlta: ($('alta-cc')?.value || '').trim(),
    celularAlta: ($('alta-celular')?.value || '').trim(),
    emailAlta: ($('alta-email')?.value || '').trim(),
    especialidadAlta: ($('alta-especialidad')?.value || '').trim(),
    ciudadAlta: ($('alta-ciudad')?.value || '').trim(),
    direccionAlta: ($('alta-direccion')?.value || '').trim(),
    observacionesAlta: ($('alta-obs')?.value || '').trim(),
    texto: `Alta: ${nombre}`,
    completada: false,
    creado: new Date().toISOString()
  });
  toast('Alta registrada', 'ok');
  state.modal = null;
  renderApp();
}

async function guardarBaja() {
  const nombre = ($('baja-nombre')?.value || '').trim();
  if (!nombre) { toast('Ingresá el nombre', 'err'); return; }
  await db.add('notas', {
    tipo: 'baja',
    nombreBaja: nombre,
    motivoBaja: ($('baja-motivo')?.value || '').trim(),
    texto: `Baja: ${nombre}`,
    completada: false,
    creado: new Date().toISOString()
  });
  toast('Baja registrada', 'ok');
  state.modal = null;
  renderApp();
}

window.handleExcelFile = async function(input) {
  const file = input.files[0];
  if (!file) return;
  toast('Procesando Excel...');
  try {
    const buf = await file.arrayBuffer();
    const res = await procesarExcelFile(buf);
    await recargarDatos();
    renderApp();
    toast(`Excel cargado: ${res.medicos} médicos, ${res.farmacias} farmacias`, 'ok');
  } catch (e) {
    toast('Error leyendo Excel: ' + e.message, 'err');
    console.error(e);
  }
  input.value = '';
};

// ===== MODAL DETALLE POR DÍA =====
function renderDiaModal(fecha) {
  setTimeout(async () => {
    const vs = await db.visitasDelMes(mesActual);
    const diaVs = vs.filter(v => v.fecha === fecha).sort((a,b) => b.creado.localeCompare(a.creado));
    const el = $('dia-detalle');
    if (!el) return;
    if (diaVs.length === 0) { el.innerHTML = '<div class="empty-state">Sin visitas este día</div>'; return; }

    const map = {};
    for (const m of medicosCache) map['medico-'+m.id] = m;
    for (const f of farmaciasCache) map['farmacia-'+f.id] = f;

    el.innerHTML = diaVs.map(v => {
      const ent = map[v.entidadTipo+'-'+v.entidadId];
      const tipoIcon = v.entidadTipo === 'medico' ? '👨‍⚕️' : '🏥';
      const nombre = ent ? ent.nombre : 'Desconocido';
      const seg = v.entidadTipo === 'medico' && ent ? obtenerSegmentos(ent).join(',') : '';
      return `
        <div class="list-item" data-action="${v.entidadTipo==='medico'?'open-medico':'open-farmacia'}" data-id="${v.entidadId}">
          <div class="list-info">
            <div class="list-name">${tipoIcon} ${esc(nombre)}</div>
            ${seg ? `<div class="list-segs" style="margin-top:4px"><span class="seg-badge seg-${seg.toLowerCase()}">${seg}</span></div>` : ''}
          </div>
        </div>
      `;
    }).join('');
    attachHandlers();
  }, 0);

  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>📅 ${fmtFecha(fecha)}</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div id="dia-detalle"><div class="empty-state">Cargando...</div></div>
        </div>
      </div>
    </div>
  `;
}

// ===== VISTA RESUMEN POR DÍA =====
function renderResumenDias() {
  db.visitasDelMes(mesActual).then(vs => {
    const el = $('resumen-dias-lista');
    if (!el) return;
    if (vs.length === 0) { el.innerHTML = '<div class="empty-state">Sin visitas este mes</div>'; return; }
    const porDia = {};
    for (const v of vs) {
      if (!porDia[v.fecha]) porDia[v.fecha] = {med:0, farm:0};
      if (v.entidadTipo === 'medico') porDia[v.fecha].med++;
      else porDia[v.fecha].farm++;
    }
    const fechas = Object.keys(porDia).sort((a,b) => b.localeCompare(a));
    const meses = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
    el.innerHTML = fechas.map(f => {
      const [yy,mm,dd] = f.split('-').map(Number);
      const label = `${dd} ${meses[mm-1]}`;
      const d = porDia[f];
      return `
        <div class="dash-dia-card" data-action="open-dia" data-fecha="${f}">
          <div class="dash-dia-fecha">${esc(label)}</div>
          <div class="dash-dia-stats">
            <span>👨‍⚕️ ${d.med}</span>
            <span>🏥 ${d.farm}</span>
          </div>
        </div>
      `;
    }).join('');
    attachHandlers();
  });

  return `
    <button class="btn btn-outline mb-1" data-action="volver-dashboard">← Volver al Dashboard</button>
    <h2 style="font-size:1.1rem;margin-bottom:12px">📅 Resumen por día</h2>
    <div id="resumen-dias-lista"><div class="empty-state">Cargando...</div></div>
  `;
}

// ===== VISTA PENDIENTES MÉDICOS =====
function renderPendientesMedicos() {
  const filtros = ['Todos','H','C','P','M','E','PS'];
  const fHtml = filtros.map(f => `<button class="pendiente-btn ${state.dashboardPendFilter===f?'active':''}" data-action="set-pend-filter" data-filtro="${f}">${f==='Todos'?'Todos':f}</button>`).join('');

  let meds = medicosCache.filter(m => {
    if (m.ciudad && !m.ciudad.toUpperCase().includes(state.pendMedCiudad)) return false;
    const v = visitasMap['medico-'+m.id] || 0;
    const freq = parseInt(m.frecuencia) || 1;
    return v < freq;
  });

  if (state.dashboardPendFilter !== 'Todos') {
    meds = meds.filter(m => obtenerSegmentos(m).includes(state.dashboardPendFilter));
  }

  meds.sort((a,b) => a.nombre.localeCompare(b.nombre));

  return `
    <button class="btn btn-outline mb-1" data-action="volver-dashboard">← Volver al Dashboard</button>
    <h2 style="font-size:1.1rem;margin-bottom:12px">👨‍⚕️ Pendientes Médicos</h2>
    <div class="city-filters">
      <button class="city-btn ${state.pendMedCiudad==='BOGOTÁ'?'active':''}" data-action="set-pend-ciudad" data-ciudad="BOGOTÁ" data-target="med">BOGOTÁ</button>
      <button class="city-btn ${state.pendMedCiudad==='IBAGUÉ'?'active':''}" data-action="set-pend-ciudad" data-ciudad="IBAGUÉ" data-target="med">IBAGUÉ</button>
    </div>
    <div class="pendientes-filters">${fHtml}</div>
    <div class="lista">
      ${meds.map(m => renderMedicoItem(m)).join('')}
      ${meds.length===0?'<div class="empty-state">No hay médicos pendientes</div>':''}
    </div>
  `;
}

// ===== VISTA PENDIENTES FARMACIAS =====
function renderPendientesFarmacias() {
  let farms = farmaciasCache.filter(f => {
    if (f.ciudad && !f.ciudad.toUpperCase().includes(state.pendFarmCiudad)) return false;
    const v = visitasMap['farmacia-'+f.id] || 0;
    const freq = parseInt(f.frecuencia) || 1;
    return v < freq;
  });

  farms.sort((a,b) => a.nombre.localeCompare(b.nombre));

  return `
    <button class="btn btn-outline mb-1" data-action="volver-dashboard">← Volver al Dashboard</button>
    <h2 style="font-size:1.1rem;margin-bottom:12px">🏥 Pendientes Farmacias</h2>
    <div class="city-filters">
      <button class="city-btn ${state.pendFarmCiudad==='BOGOTÁ'?'active':''}" data-action="set-pend-ciudad" data-ciudad="BOGOTÁ" data-target="farm">BOGOTÁ</button>
      <button class="city-btn ${state.pendFarmCiudad==='IBAGUÉ'?'active':''}" data-action="set-pend-ciudad" data-ciudad="IBAGUÉ" data-target="farm">IBAGUÉ</button>
    </div>
    <div class="lista">
      ${farms.map(f => renderFarmaciaItem(f)).join('')}
      ${farms.length===0?'<div class="empty-state">No hay farmacias pendientes</div>':''}
    </div>
  `;
}

// ===== MODAL EDITAR VISITA =====
function renderEditarVisitaModal(id, fecha) {
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>✏️ Editar fecha de visita</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">Nueva fecha</label>
            <input type="date" class="input-fecha-edit" id="edit-visita-fecha" value="${fecha}">
          </div>
          <button class="btn btn-primary" data-action="guardar-visita-editada" data-id="${id}">Guardar cambio</button>
        </div>
      </div>
    </div>
  `;
}

async function guardarVisitaEditada(data) {
  const nuevaFecha = $('edit-visita-fecha')?.value;
  if (!nuevaFecha) { toast('Seleccioná una fecha', 'err'); return; }
  const visita = await db.getById('visitas', parseInt(data.id));
  if (!visita) { toast('Visita no encontrada', 'err'); return; }
  visita.fecha = nuevaFecha;
  visita.mes = nuevaFecha.slice(0,7);
  await db.put('visitas', visita);
  await recargarDatos();
  toast('Fecha actualizada', 'ok');
  state.modal = null;
  renderApp();
}

function renderEditarMedicoModal(id) {
  const m = medicosCache.find(x => x.id === id);
  if (!m) return '';
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>Editar médico</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Nombre</label><input id="edit-med-nombre" value="${esc(m.nombre)}"></div>
          <div class="form-group"><label>Especialidad</label><input id="edit-med-especialidad" value="${esc(m.especialidad)}"></div>
          <div class="form-group"><label>Dirección</label><input id="edit-med-direccion" value="${esc(m.direccion)}"></div>
          <div class="form-group"><label>Celular</label><input id="edit-med-celular" value="${esc(m.celular)}"></div>
          <div class="form-group"><label>Email</label><input id="edit-med-email" value="${esc(m.email)}"></div>
          <div class="form-group"><label>Brick</label><input id="edit-med-brick" value="${esc(m.brick)}"></div>
          <div class="form-group"><label>Frecuencia</label><input id="edit-med-frecuencia" type="number" value="${m.frecuencia||1}"></div>
          <button class="btn-primary" data-action="guardar-medico" data-id="${m.id}">Guardar</button>
        </div>
      </div>
    </div>
  `;
}

async function guardarMedico(data) {
  const m = medicosCache.find(x => x.id === parseInt(data.id));
  if (!m) { toast('Médico no encontrado', 'err'); return; }
  m.nombre = $('edit-med-nombre')?.value || m.nombre;
  m.especialidad = $('edit-med-especialidad')?.value || m.especialidad;
  m.direccion = $('edit-med-direccion')?.value || m.direccion;
  m.celular = $('edit-med-celular')?.value || m.celular;
  m.email = $('edit-med-email')?.value || m.email;
  m.frecuencia = parseInt($('edit-med-frecuencia')?.value) || m.frecuencia;
  const nuevoBrick = $('edit-med-brick')?.value?.trim();
  if (nuevoBrick !== undefined) {
    m.brick = nuevoBrick;
    m.brickZona = getBrickZona(nuevoBrick);
  }
  await db.put('medicos', m);
  await recargarDatos();
  toast('Médico actualizado', 'ok');
  state.modal = null;
  renderApp();
}

function renderEditarFarmaciaModal(id) {
  const f = farmaciasCache.find(x => x.id === id);
  if (!f) return '';
  return `
    <div class="modal" data-action="close-modal">
      <div class="modal-sheet" onclick="event.stopPropagation()">
        <div class="modal-header">
          <h3>Editar farmacia</h3>
          <button class="btn-icon" data-action="close-modal">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label>Nombre</label><input id="edit-farm-nombre" value="${esc(f.nombre)}"></div>
          <div class="form-group"><label>Cadena</label><input id="edit-farm-cadena" value="${esc(f.cadena)}"></div>
          <div class="form-group"><label>Dirección</label><input id="edit-farm-direccion" value="${esc(f.direccion)}"></div>
          <div class="form-group"><label>Brick</label><input id="edit-farm-brick" value="${esc(f.brick)}"></div>
          <div class="form-group"><label>Frecuencia</label><input id="edit-farm-frecuencia" type="number" value="${f.frecuencia||1}"></div>
          <button class="btn-primary" data-action="guardar-farmacia" data-id="${f.id}">Guardar</button>
        </div>
      </div>
    </div>
  `;
}

async function guardarFarmacia(data) {
  const f = farmaciasCache.find(x => x.id === parseInt(data.id));
  if (!f) { toast('Farmacia no encontrada', 'err'); return; }
  f.nombre = $('edit-farm-nombre')?.value || f.nombre;
  f.cadena = $('edit-farm-cadena')?.value || f.cadena;
  f.direccion = $('edit-farm-direccion')?.value || f.direccion;
  f.frecuencia = parseInt($('edit-farm-frecuencia')?.value) || f.frecuencia;
  const nuevoBrickFarm = $('edit-farm-brick')?.value?.trim();
  if (nuevoBrickFarm !== undefined) {
    f.brick = nuevoBrickFarm;
    f.brickZona = getBrickZona(nuevoBrickFarm);
  }
  await db.put('farmacias', f);
  await recargarDatos();
  toast('Farmacia actualizada', 'ok');
  state.modal = null;
  renderApp();
}

// Checkbox toggle en modal nota
setInterval(() => {
  const cb = $('nota-cal');
  const wrap = $('nota-fecha-wrap');
  if (cb && wrap) wrap.classList.toggle('hidden', !cb.checked);
}, 200);

// Init
document.addEventListener('DOMContentLoaded', init);
